document.getElementById("cnt").textContent = "스크립트가 채운 값";
